package de.simpleworks.staf.devicetesting.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import de.simpleworks.staf.commons.annotation.Property;
import de.simpleworks.staf.commons.annotation.Property.Default;
import de.simpleworks.staf.commons.utils.PropertiesReader;
import de.simpleworks.staf.devicetesting.consts.DeviceTestingConsts;

public class AppiumDriverProperties extends PropertiesReader {

	private static final Logger logger = LogManager.getLogger(AppiumDriverProperties.class);
	private static AppiumDriverProperties instance = null;
	@Property(DeviceTestingConsts.APPIUM_DEVICENAME)
	private String deviceName;
	@Property(DeviceTestingConsts.PLATFORM_VERSION)
	private int platformVersion;
	@Property(DeviceTestingConsts.APPIUM_PLATFORMNAME)
	private String platformName;
	@Property(DeviceTestingConsts.APPIUM_APPPACKAGE)
	private String appPackage;
	@Property(DeviceTestingConsts.APPIUM_APPACTIVITY)
	private String appActivity;
	@Default("http://127.0.0.1:4723/wd/hub")
	@Property(DeviceTestingConsts.APPIUM_SERVER_URL)
	private String appiumServerUrl;

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public int getPlatformVersion() {
		return platformVersion;
	}

	public void setPlatformVersion(int platformVersion) {
		this.platformVersion = platformVersion;
	}

	public String getPlatformName() {
		return platformName;
	}

	public void setPlatformName(String platformName) {
		this.platformName = platformName;
	}

	public String getAppPackage() {
		return appPackage;
	}

	public void setAppPackage(String appPackage) {
		this.appPackage = appPackage;
	}

	public String getAppActivity() {
		return appActivity;
	}

	public void setAppActivity(String appActivity) {
		this.appActivity = appActivity;
	}

	public String getAppiumServerUrl() {
		return appiumServerUrl;
	}

	public void setAppiumServerUrl(String appiumServerUrl) {
		this.appiumServerUrl = appiumServerUrl;
	}

	@Override
	protected Class<?> getClazz() {
		return AppiumDriverProperties.class;
	}

	public static final synchronized AppiumDriverProperties getInstance() {
		if (AppiumDriverProperties.instance == null) {
			if (AppiumDriverProperties.logger.isDebugEnabled()) {
				AppiumDriverProperties.logger.debug("create instance.");
			}
			AppiumDriverProperties.instance = new AppiumDriverProperties();
		}
		return AppiumDriverProperties.instance;
	}
}