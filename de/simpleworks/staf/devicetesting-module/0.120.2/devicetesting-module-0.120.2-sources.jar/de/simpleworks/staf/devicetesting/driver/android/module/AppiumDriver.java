package de.simpleworks.staf.devicetesting.driver.android.module;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import de.simpleworks.staf.commons.utils.Convert;
import de.simpleworks.staf.devicetesting.consts.DeviceTestingConsts;
import de.simpleworks.staf.devicetesting.utils.AppiumDriverProperties;
import de.simpleworks.staf.framework.gui.webdriver.module.WebDriverManagerImpl;
import io.appium.java_client.android.AndroidDriver;

public class AppiumDriver extends WebDriverManagerImpl {

	private AppiumDriverProperties properties = AppiumDriverProperties.getInstance();

	public AppiumDriver() {
		if (Convert.isEmpty(properties.getDeviceName())) {
			throw new RuntimeException(String.format("PROPERTY '%s' can't be null or empty string.",
					DeviceTestingConsts.APPIUM_DEVICENAME));
		}
		if (properties.getPlatformVersion() <= 0) {
			throw new RuntimeException(String.format("PROPERTY '%s' can't be less or equal to zero.",
					Integer.toString(properties.getPlatformVersion())));
		}
		if (Convert.isEmpty(properties.getPlatformName())) {
			throw new RuntimeException(String.format("PROPERTY '%s' can't be null or empty string.",
					DeviceTestingConsts.APPIUM_PLATFORMNAME));
		}
		if (Convert.isEmpty(properties.getAppPackage())) {
			throw new RuntimeException(String.format("PROPERTY '%s' can't be null or empty string.",
					DeviceTestingConsts.APPIUM_APPPACKAGE));
		}
		if (Convert.isEmpty(properties.getAppActivity())) {
			throw new RuntimeException(String.format("PROPERTY '%s' can't be null or empty string.",
					DeviceTestingConsts.APPIUM_APPACTIVITY));
		}
		if (Convert.isEmpty(properties.getAppiumServerUrl())) {
			throw new RuntimeException(String.format("PROPERTY '%s' can't be null or empty string.",
					DeviceTestingConsts.APPIUM_APPPACKAGE));
		}
	}

	@Override
	protected WebDriver createDriver() {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("appium:deviceName", properties.getDeviceName());
		capabilities.setCapability("platformVersion", Integer.toString(properties.getPlatformVersion()));
		capabilities.setCapability("appium:platformName", properties.getPlatformName());
		capabilities.setCapability("appium:appPackage", properties.getAppPackage());
		capabilities.setCapability("appium:appActivity", properties.getAppActivity());
		URL url;
		final String urlFromAppiumServer = properties.getAppiumServerUrl();
		try {
			url = new URL(urlFromAppiumServer);
		} catch (MalformedURLException ex) {
			final String msg = String.format("can't set up URL from '%s'.", urlFromAppiumServer);
			throw new RuntimeException(msg, ex);
		}

		AndroidDriver AppiumDriver = new AndroidDriver(url, capabilities);
		if (!(AppiumDriver instanceof WebDriver)) {
			throw new RuntimeException(String.format("AppiumDriver is no instance of \"%s\".", WebDriver.class));
		}
		WebDriver result = (WebDriver) AppiumDriver;
		return result;
	}
}